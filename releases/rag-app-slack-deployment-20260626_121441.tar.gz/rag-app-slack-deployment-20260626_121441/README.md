# RAG App Slack Integration - Helm Deployment Package

Status: Ready for Production Deployment

## Quick Start

### Extract Package
tar -xzf rag-app-slack-deployment-20260626_121441.tar.gz
cd rag-app-slack-deployment-20260626_121441

### Deploy to Kubernetes

#### Windows PowerShell
cd helm
.\Deploy-Helm.ps1 -Action deploy

#### Linux/Mac/WSL
cd helm
chmod +x deploy-helm.sh
./deploy-helm.sh deploy

## Documentation
1. START_HERE.md - Quick start
2. HELM_PACKAGE_SUMMARY.md - Overview
3. DEPLOYMENT_CHECKLIST.md - Pre-deployment
4. helm/HELM_DEPLOYMENT_GUIDE.md - Complete guide

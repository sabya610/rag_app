# RAG App Slack Integration - PCAI Merged Deployment Package

Status: PRODUCTION-READY

## Quick Start

### Extract Package
tar -xzf rag-app-slack-merged-deployment.tar.gz
cd rag-app-slack-merged-deployment

### Deploy to PCAI

#### Windows PowerShell
cd helm
.\Deploy-Helm.ps1

#### Linux/Mac/WSL
cd helm
chmod +x deploy-helm.sh
./deploy-helm.sh

### Key Files

- helm/values-pcai-merged.yaml .... RECOMMENDED for migration
- helm/values-pcai.yaml ........... Fresh PCAI install
- helm/values-ftc-aie.yaml ........ FTC cluster specific

### Documentation Order

1. MIGRATION_INDEX.md ............. START HERE
2. QUICK_MIGRATION_CARD.md ........ 30-minute fast track
3. MIGRATION_SUMMARY.md ........... Comparison overview
4. MIGRATION_PLAYBOOK.md .......... Step-by-step guide
5. helm/HELM_DEPLOYMENT_GUIDE.md .. Complete deployment reference

## What's Included

✅ Complete Helm chart
✅ Three values files (FTC, PCAI basic, PCAI merged)
✅ Deployment automation scripts
✅ Comprehensive documentation (9 guides)
✅ Security audit and fixes
✅ Migration playbooks and checklists
✅ Quick reference cards

## Configuration Files

helm/values-pcai-merged.yaml - RECOMMENDED
  - Merges existing deployment + PCAI improvements
  - Preserves SFDC and EZUA integration
  - Adds Slack integration
  - Implements all security fixes
  - Ready for production migration

helm/values-pcai.yaml
  - Basic PCAI configuration
  - Use for fresh installations
  - Includes all security hardening

helm/values-ftc-aie.yaml
  - Optimized for FTC AIE 1.1.1 cluster
  - Pre-configured with cluster settings

## Support

See MIGRATION_INDEX.md for documentation navigation
See QUICK_MIGRATION_CARD.md for deployment commands
See MIGRATION_PLAYBOOK.md for troubleshooting

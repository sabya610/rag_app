# START HERE

## Extract and Deploy

tar -xzf rag-app-slack-deployment-20260626_115713.tar.gz
cd rag-app-slack-deployment-20260626_115713/helm

# Windows:
.\Deploy-Helm.ps1 -Action deploy

# Linux/Mac:
./deploy-helm.sh deploy

## Documentation Order
1. README.md
2. ../HELM_PACKAGE_SUMMARY.md
3. ../DEPLOYMENT_CHECKLIST.md
4. HELM_DEPLOYMENT_GUIDE.md
